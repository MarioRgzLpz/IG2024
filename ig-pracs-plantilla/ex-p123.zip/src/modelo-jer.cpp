// Nombre: Mario, Apellidos: Rodriguez Lopez, Titulación: GIM .
// email: MarioRgzLpz@correo.ugr.es, DNI o pasaporte: 74539226K

#include "modelo-jer.h"
#include "malla-ind.h"
#include "malla-revol.h"
using namespace glm;

Nave::Nave()
{
    ponerNombre("Nave");
    unsigned ind = agregar(translate(vec3(0.0,0.0,0.0)));
    agregar( new Fuselaje() );
    agregar( new Cabeza() );
    agregar( new Motor(rot_motor) );
    agregar( new Cohete() );
    agregar( new Fuego(tras_fuego) );
    agregar( new Ala() );
    agregar(rotate(float(M_PI), glm::vec3( 1.0, 0.0, 0.0) ));
    agregar(translate(glm::vec3(0.0, -0.25, 0.0)));
    agregar( new Ala() );
    agregar(rotate(float(M_PI/2), glm::vec3( 0.5, 0.0, 0.0) ));
    agregar(translate(glm::vec3(2.4, -0.04, 0.0)));
    agregar(scale(glm::vec3(0.3,0.3,0.3)));
    agregar( new Ala() );
    tras_nave = leerPtrMatriz(ind);



}

unsigned Nave::leerNumParametros() const
{
    return 3;
}

void Nave::actualizarEstadoParametro(const unsigned iParam, const float t_sec)
{
    assert(iParam < leerNumParametros());
    float v;
 switch(iParam)
    {
        case 0:
            {
                v = 0 + 2*sin( 2*M_PI * 0.2 * t_sec);
                *tras_nave = translate( glm::vec3( v, 0.0, 0.0));
            }
            break;
        case 1:
            {    
                v = 0 + 2*M_PI*2.5*t_sec;
                *rot_motor = rotate( v, glm::vec3( 1.0, 0.0, 0.0));
            }
            break;
        case 2:
            {
                v = 3.0 - 0.5*sin( 2*M_PI * 0.2 * t_sec);
                *tras_fuego = translate( glm::vec3( v, 0.0, 0.0));

            }
    }              
}

Fuselaje::Fuselaje()
{

    agregar(translate(glm::vec3(2.5,0.0,0.0)));
    agregar(rotate(float(M_PI/2), glm::vec3( 0.0, 0.0, 1.0) ));   
    agregar(scale(glm::vec3(0.5,5,0.5)));
    agregar(new Cilindro(20,15));
}

Ala::Ala()
{

    agregar(translate(glm::vec3(0.0,0.25,0.45)));
    agregar(rotate(float(M_PI), glm::vec3( 0.0, 0.0, 1.0) ));
    agregar(scale(glm::vec3(1.5,0.25,3.0))); 
    agregar(new BaseAla());
}

Motor::Motor(glm::mat4 *&movimiento){

    agregar(scale(glm::vec3(1.5,1.5,1.5)));
    unsigned ind = agregar(rotate(float(M_PI),(glm::vec3( 1.0, 0.0, 0.0) )));
    agregar(translate(glm::vec3(-2.3,-0.5,-0.5)));
    agregar(new Aspas(4));
    movimiento = leerPtrMatriz(ind);

}

Cabeza::Cabeza(){
    agregar(translate(glm::vec3(-2.5,0.0,0.0)));
    agregar(scale(glm::vec3(1.0,0.5,0.5)));
    agregar(new Esfera(15,20));
}

Cohete::Cohete(){
    ponerColor({0.0, 0.0, 0.0});
    agregar(translate(glm::vec3(2.55,0.0,0.0)));
    agregar(rotate(float(M_PI/2), glm::vec3( 0.0, 0.0, 1.0) ));  
    agregar(scale(glm::vec3(0.55,0.55,0.55)));
    agregar(new Cono(20,15));
}

Fuego::Fuego(glm::mat4 *&movimiento){
    ponerColor({1.0, 0.0, 0.0});
    unsigned ind = agregar(translate(glm::vec3(3.0,0.0,0.0)));
    agregar(rotate(float(M_PI/2), glm::vec3( 0.0, 0.0, 1.0) ));   
    agregar(scale(glm::vec3(0.45,1,0.45)));
    agregar(new Cilindro(20,15));
    movimiento = leerPtrMatriz(ind);
}

